import * as s from './article.service.js';
import { sendCreated, sendSuccess } from '../../utils/apiResponse.js';
export async function list(req, res) {
  const r = await s.list(req.query);
  return sendSuccess(res, { data: r.items, meta: r.meta });
}
export async function detail(req, res) {
  return sendSuccess(res, { data: await s.detail(req.params.slug) });
}
export async function tip(req, res) {
  return sendCreated(
    res,
    await s.submitTip(req.user?._id ?? null, req.body),
    'Đã gửi thông tin tới Ban biên tập.',
  );
}
export async function adminList(req, res) {
  const r = await s.adminList(req.query);
  return sendSuccess(res, { data: r.items, meta: r.meta });
}
export async function adminCreate(req, res) {
  return sendCreated(res, await s.adminCreate(req.user._id, req.body), 'Đã tạo bài viết.');
}
export async function adminUpdate(req, res) {
  return sendSuccess(res, {
    data: await s.adminUpdate(req.params.id, req.user._id, req.body),
    message: 'Đã cập nhật bài viết.',
  });
}
